#library import
import mysql.connector as sql

#setting connection
mydb = sql.connect(
    host="localhost",
    user="root",
    password="password",
    charset="utf8mb4",
    collation="utf8mb4_general_ci"  # Change to a supported collation
)
#making cursor
cr = mydb.cursor()

#creating database
q = "create database super_markett"
cr.execute(q)
q = "use super_markett"
cr.execute(q)

#bakery
q = '''create table bakery(cid integer primary key,
cake varchar(30) not null,
flavour varchar(50),
dateofm date,
weight float,
content varchar(100),
price float)'''
cr.execute(q)

#BILLS
q = '''create table bills(store_name varchar(15) not null,
cname varchar(20),
date_of_pur date,
amount float)'''
cr.execute(q)

mydb.commit()
print("Done")
